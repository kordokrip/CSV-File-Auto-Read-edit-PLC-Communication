﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Linq;
using System.Text;
using System.IO;

namespace COB_Manager.Common
{
    public class ModelInfo : NotifyPropertyChanged
    {
        #region Properties.

        /// <summary>   Gets or sets the LotNo. </summary>
        /// <value> The LotNo. </value>
        [XmlIgnore]
        public string LotNo
        {
            get
            {
                return m_strLotNo;
            }
            set
            {
                m_strLotNo = value;
                Notify("LotNo");
            }
        }

        /// <summary>   Gets or sets the Customer. </summary>
        /// <value> The Customer. </value>
        [XmlIgnore]
        public int GoodCount
        {
            get
            {
                return m_nGoodCount;
            }
            set
            {
                m_nGoodCount = value;
                Notify("GoodCount");
            }
        }

        /// <summary>   Gets or sets the Rows. </summary>
        /// <value> The Rows. </value>
        [XmlIgnore]
        public int BadCount
        {
            get
            {
                return m_nBadCount;
            }
            set
            {
                m_nBadCount = value;
                Notify("BadCount");
            }
        }


        /// <summary>   Gets or sets the PF. </summary>
        /// <value> The PF. </value>
        [XmlIgnore]
        public double Length
        {
            get
            {
                return m_fLength;
            }
            set
            {
                m_fLength = value;
                Notify("Length");
            }
        }

        /// <summary>   Gets or sets the TotalCount. </summary>
        /// <value> The TotalCount. </value>
        [XmlIgnore]
        public int Joint
        {
            get
            {
                return m_nJoint;
            }
            set
            {
                m_nJoint = value;
                Notify("Joint");
            }
        }

        public int Total { get; set; }
        #endregion Properties.

        public bool[,] ReelMap;

        #region Private member variables.
        private string m_strLotNo;
        private int m_nGoodCount;
        private int m_nBadCount;
        private int m_nJoint;
        private double m_fLength;

        public int Customer;
        public int Columns;
        public int Rows;
        public int PF;

        #endregion Private member variables.

        public bool FileLoaded;

        #region Function

        //Default Constructor.
        public ModelInfo()
        {
            LotNo = "";
        }

        private int GetCustomerType(string code, System.Collections.ObjectModel.ObservableCollection<Customer> lst)
        {
            for (int i= 0; i< lst.Count; i++)
            {
                if (code == lst[i].Code)
                {
                    return lst[i].Type;
                }
            }
            return 0;
        }
        
        //File Constructor.
        //astrFilePath is ReelMap File Full Path and File Name.
        //bReadMap is Reading ReelMap Flags. Default False.
        public ModelInfo(string astrFilePath, System.Collections.ObjectModel.ObservableCollection<Customer> lst, bool bReadMap = false)
        {
            StreamReader file;
            try
            {
                file = new StreamReader(astrFilePath, Encoding.Default);
            }
            catch
            {
                FileLoaded = false;
                return;
            }
            string line;
            bool bEndRead = false;
            try
            {
                this.Total = 0;
                while (!bEndRead)
                {
                    line = file.ReadLine();
                    if (line == null) break;
                    string[] sp = line.Split(',');
                    if (sp.Length < 1) continue;
                    try
                    {
                        switch (sp[0])
                        {
                            //case "모델명": this.ModelName = sp[1]; break;
                            //case "검사수": this.Total = Convert.ToInt32(sp[1]); break;
                            case "Lot No": this.LotNo = sp[1]; break;
                            case "고객코드": this.Customer = GetCustomerType(sp[1], lst); break;
                            case "PF": this.PF = Convert.ToInt32(sp[1]); break;
                            case "열수":
                                this.Rows = Convert.ToInt32(sp[1]);
                                if (!bReadMap) bEndRead = true;
                                else
                                {
                                    Columns = Total / Rows;
                                    List<string> Maps = new List<string>();
                                    file.ReadLine();
                                    while (true)
                                    {
                                        string map = file.ReadLine();
                                        if (map == null) break;
                                        if (map.Contains("TOP")) break;
                                        Maps.Add(map);
                                    }
                                    MapParse(Maps);
                                    bEndRead = true;
                                }
                                break;
                            case "검사수": Total = Convert.ToInt32(sp[1]); break;
                            case "NG수": this.BadCount = Convert.ToInt32(sp[1]); break;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
                FileLoaded = false;
            }
            finally
            {
                file.Close();
            }
            FileLoaded = true;
        }
           
        // MapParse 
        private void MapParse(List<string> lstMap)
        {
           
            this.ReelMap = new bool[Rows, Columns];
            int k = 0;
            for (int i = 0; i < lstMap.Count-1; i++)
            {
                for (int j = 0; j < Rows; j++)
                { 
                    string[] sp = lstMap[i].Split(',');
                    if (sp.Length > 1)
                    {
                        for (int n = 1; n < Math.Min(sp.Length, 51); n++)
                        {
                            if (sp[n] == "") break; 
                            this.ReelMap[j, (k * 50) + n - 1] = (sp[n] == "G") ? true : false;
                        }
                    }
                    i++;
                }
                i--;
                k++;
            }
        }

        public bool IsEdit()
        {
            switch (this.Customer)
            {
                case 0:
                    int ncnt1 = 0;
                    int ncnt2 = 0;
                    for (int i = 0; i < Columns; i++)
                    {
                        int nBad = 0;
                        for (int j = 0; j < Rows; j++)
                        {
                            if (!this.ReelMap[j, i]) nBad++;
                        }
                        if (nBad == Rows) ncnt2++; else ncnt2 = 0;
                        if (ncnt2 >= 4) return true;
                        if (nBad > 0) ncnt1++;
                        else ncnt1 = 0;
                        if (ncnt1 >= 8) return true;
                    }
                    break;
                case 1:
                    int[] cnt = new int[this.Rows];
                    for (int i = 0; i < Rows; i++) cnt[i] = 0;
                    for (int i = 0; i < Columns; i++)
                    {
                        for (int j = 0; j < Rows; j++)
                        {
                            if (!this.ReelMap[j, i]) cnt[j]++;
                            else cnt[j] = 0;
                            if (cnt[j] > 6) return true;
                        }
                    }
                    break;
            }

            return false;
        }
        #endregion
    }


    #region Notify Event

    [Serializable]
    public class NotifyPropertyChanged : INotifyPropertyChanged
    {
 
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>   Notifies. </summary>
        /// <remarks>   suoow2, 2014-08-09. </remarks>
        /// <param name="strPropertyName">  Name of the property. </param>
        public void Notify(string strPropertyName)
        {
            PropertyChangedEventHandler p = PropertyChanged;
            if (p != null)
            {
                p(this, new PropertyChangedEventArgs(strPropertyName));
            }
        }
    }
    #endregion Notify Event
}
