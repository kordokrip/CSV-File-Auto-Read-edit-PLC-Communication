﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.ComponentModel;

namespace COB_Manager.Common
{
    public class LotInfo : NotifyPropertyChanged
    {
        public LotInfo(int index, string lotno)
        {
            Index = index;
            LotNo = lotno;
        }
        public int Index
        {
            get { return m_nIndex; }
            set
            {
                m_nIndex = value;
                Notify("Index");
            }
        }
        public string LotNo
        {
            get { return m_strLotNo; }
            set
            {
                m_strLotNo = value;
                Notify("LotNo");
            }
        }
        private int m_nIndex;
        private string m_strLotNo;
    }

    public delegate void LotInfoChangedEventHandler(ObservableCollection<LotInfo> lst);

    public class FileCheck_Thread
    {

        public static Information Info;
        public event LotInfoChangedEventHandler LotInfoChanged;
        private Thread CheckThd;
        private string[] SrcDir;
        private string InspDoneDir;
        private string EditDir;
        private string MESDir;
        private int Wait;
        private bool Started;
        private ObservableCollection<Customer> Customers;
       
        //Constructor
        //astrSrcDir             검사기 Map 경로
        //astrInspectDoneDir     편집이 없을 경우 복사 할 경로
        //astrEditPDir           편집이 있을 경우 복사 할 경로
        //anSleep                읽기 대기 시간 초



        public FileCheck_Thread(ObservableCollection<AFVI_Info> afvi, string astrInspectDoneDir, string astrEditPDir, string astrMESDir, int anSleep, ObservableCollection<Customer> lst)
        {
            Customers = lst;
            Wait = anSleep;
            //빈 경로가 추가? afvi.Count = 2 -> 1?
            SrcDir = new string[afvi.Count];
            for (int i = 0; i < afvi.Count; i++)
            {
                SrcDir[i] = afvi[i].Path;
            }
            InspDoneDir = astrInspectDoneDir;
            EditDir = astrEditPDir;
            MESDir = astrMESDir;
            try
            {
                if (!Directory.Exists(InspDoneDir)) Directory.CreateDirectory(InspDoneDir);
                if (!Directory.Exists(EditDir)) Directory.CreateDirectory(EditDir);
            }
            catch
            {
                return;
            }
            Thread.Sleep(10);
            //10초 후 시작 한다
            CreateThread();
        }

        private void CreateThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
            CheckThd = new Thread(FileCheck);
            CheckThd.Start();
        }

        public void DisposeThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
        }

        private void FileCheck()
        {
            Started = true;
            int nCnt = Wait * 10;
            while (Started)
            {
                
                if (Started)
                {
                    for (int i = 0; i < SrcDir.Length; i++)
                    {
                        string[] files = Directory.GetFiles(SrcDir[i], "*.csv");
                        if (files.Length > 0)
                        {
                            foreach (string file in files)
                            {
                                EditCheck(file, SrcDir[i]);
                            }
                        }
                        files = Directory.GetFiles(EditDir, "*.csv");
                        ObservableCollection<LotInfo> lot = new ObservableCollection<LotInfo>();
                        int n = 0;
                        foreach (string name in files)
                        {
                            string[] tmp = name.Split('\\', '.');
                            if (tmp.Length > 2)
                            {
                                LotInfo l = new LotInfo(++n, tmp[tmp.Length-2]);
                                lot.Add(l);
                            }
                        }
                        LotInfoChangedEventHandler er= LotInfoChanged;
                        if (er != null) er(lot);
                    }
                }
                for (int i = 0; i < nCnt; i++)
                {
                    Thread.Sleep(100);
                    if (!Started) break;
                }
            }
        }

        public bool EditCheck(string astrFile, string path)
        {
            ModelInfo model = new ModelInfo(astrFile, Customers, true);
            
            if (model.FileLoaded)
            { 
                if (model.IsEdit())
                {
                    String new_path = astrFile.Replace(path, EditDir);
                    if (File.Exists(new_path))
                    {
                        File.Delete(new_path);
                    }
                    File.Move(astrFile, astrFile.Replace(path, EditDir));
                }
                else
                {
                   
                    String new_path = astrFile.Replace(path, InspDoneDir);
                    if (File.Exists(new_path))
                    {
                        File.Delete(new_path);
                    }
                    File.Move(astrFile, new_path);
                    Counter_End(model);
         
                  
                }
            }
            return true;
        }
        private bool Counter_End(ModelInfo info)
        {

            try
            {
                if (File.Exists(MESDir + "\\" + info.LotNo + ".txt")) File.Delete(MESDir + "\\" + info.LotNo + ".txt");
                FileStream fs = File.Create(MESDir + "\\" + info.LotNo + ".txt");
                fs.Close();
                double length = (info.Total / info.Rows) * info.PF * 4.75 / 1000.0;
                info.GoodCount = info.Total - info.BadCount;
                string str = info.GoodCount.ToString() + "\t" + info.BadCount.ToString() + "\t" + length.ToString("F2") + "\t" + info.Joint.ToString();
                File.WriteAllText(MESDir + "\\" + info.LotNo + ".txt", str);
            }
            catch (System.Exception ex)
            {
                return false;
            }
            return true;

        }
    }
}
