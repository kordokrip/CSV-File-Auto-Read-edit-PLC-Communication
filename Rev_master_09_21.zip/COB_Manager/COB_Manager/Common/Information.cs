﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.IO;

namespace COB_Manager.Common
{
   
    public class Information
    {
        public bool UsePLC;
        public string EditPath;
        public string MESPath;
        public string InspDonePath;
        public string CustomerCode;
        public ObservableCollection<Customer> Customers = new ObservableCollection<Customer>();
        public ObservableCollection<RMV_Info> RMV = new ObservableCollection<RMV_Info>();
        public ObservableCollection<AFVI_Info> AFVI = new ObservableCollection<AFVI_Info>();
        private string m_path = Environment.CurrentDirectory + "\\..\\config\\Info.ini";
        private string m_Custpath = Environment.CurrentDirectory + "\\..\\config\\Customer.ini";

        public bool Load()
        {
            if (!File.Exists(m_path)) File.Create(m_path);
            IniFile ini = new IniFile(m_path);
            UsePLC = ini.ReadBool("PLC", "Used", false);
            EditPath = ini.ReadString("PATH", "EDITPATH", "d:\\edit");
            MESPath = ini.ReadString("PATH", "MESPath", @"\\192.168.50.191\cob_data"); 
            InspDonePath = ini.ReadString("PATH", "INSPDONEPATH", "d:\\inspdone");
            CustomerCode = ini.ReadString("PATH", "CUSTOMERCODE", "d:\\edit");
            int cnt = ini.ReadInteger("AFVI", "COUNT", 0);
            AFVI.Clear();
            for (int i = 0; i < cnt; i++)
            {
                AFVI_Info r = new AFVI_Info();
                r.Index = i + 1;
                r.Code = ini.ReadString("AFVI", "CODE" + (i+1).ToString(), "");
                r.Path = ini.ReadString("AFVI", "PATH" + (i + 1).ToString(), "");
                AFVI.Add(r);
            }
            cnt = ini.ReadInteger("RMV", "COUNT", 0);
            RMV.Clear();
            for (int i = 0; i < cnt; i++)
            {
                RMV_Info r = new RMV_Info();
                r.Index = i + 1;
                r.Code = ini.ReadString("RMV", "CODE" + (i + 1).ToString(), "");
                r.IP = ini.ReadString("RMV", "IP" + (i + 1).ToString(), "");
                //r.Port = ini.ReadString("RMV", "PORT" + (i + 1).ToString(), "");
                r.StationNumber = ini.ReadInteger("RMV", "StationNumber"+ (i + 1).ToString(), 0);
                RMV.Add(r);
            }
            Customers.Clear();
            if (!File.Exists(m_Custpath)) File.Create(m_Custpath);
            IniFile iniCust = new IniFile(m_Custpath);
            int n = iniCust.ReadInteger("Cutomer", "Count", 0);
            for (int i =0; i<n;i++)
            {
                string code = iniCust.ReadString("Customer" + (1 + i).ToString(), "Code", "");
                int ntype = iniCust.ReadInteger("Customer" + (1 + i).ToString(), "Type", 0);
                Customer c = new Customer(code, ntype);
                Customers.Add(c);
            }

            return true;
        }

        public bool Save()
        {
            if (!File.Exists(m_path)) File.Create(m_path);
            IniFile ini = new IniFile(m_path);
           // ini.WriteBool("PLC", "Used", UsePLC);
            ini.WriteString("PATH", "EDITPATH", EditPath);
            ini.WriteString("PATH", "MESPath", MESPath);
            ini.WriteString("PATH", "INSPDONEPATH", InspDonePath);
          
            int cnt = AFVI.Count;
            ini.WriteInteger("AFVI", "COUNT", cnt);
            for (int i = 0; i < cnt; i++)
            {
                ini.WriteString("AFVI", "CODE" + (i + 1).ToString(), AFVI[i].Code);
                ini.WriteString("AFVI", "PATH" + (i + 1).ToString(), AFVI[i].Path);
            }
            cnt = RMV.Count;
            ini.WriteInteger("RMV", "COUNT", cnt); 
            for (int i = 0; i < cnt; i++)
            {
                ini.WriteString("RMV", "CODE" + (i + 1).ToString(), RMV[i].Code);
                ini.WriteString("RMV", "IP" + (i + 1).ToString(), RMV[i].IP);
                //ini.WriteString("RMV", "PORT" + (i + 1).ToString(), RMV[i].Port);
                ini.WriteInteger("RMV", "StationNumber" + (i + 1).ToString(), RMV[i].StationNumber);
            }

            if (!File.Exists(m_Custpath)) File.Create(m_Custpath);
            IniFile iniCust = new IniFile(m_Custpath);
            iniCust.WriteInteger("Cutomer", "Count", Customers.Count);
            for (int i = 0; i < Customers.Count; i++)
            {
                iniCust.WriteString("Customer" + (1 + i).ToString(), "Code", Customers[i].Code);
                iniCust.WriteInteger("Customer" + (1 + i).ToString(), "Type", Customers[i].Type);
            }
            return true;
        }

        public Information CopyTo()
        {
            Information info = new Information();
            info.EditPath = this.EditPath;
            info.InspDonePath = this.InspDonePath;
            for (int i = 0; i < this.AFVI.Count; i++)
            {
                AFVI_Info a = new AFVI_Info();
                a.Index = this.AFVI[i].Index;
                a.Code = this.AFVI[i].Code;
                a.Path = this.AFVI[i].Path;
                info.AFVI.Add(a);
            }
            for (int i = 0; i < this.RMV.Count; i++)
            {
                RMV_Info a = new RMV_Info();
                a.Index = this.RMV[i].Index;
                a.Code = this.RMV[i].Code;
                a.IP = this.RMV[i].IP;
                //  a.Port = this.RMV[i].Port;
                a.StationNumber = this.RMV[i].StationNumber;
                info.RMV.Add(a);
            }
            for (int i=0; i<Customers.Count; i++)
            {
                Customer c = new Customer(this.Customers[i].Code, this.Customers[i].Type);
                info.Customers.Add(c);
            }
            return info;
        }
    }

    public class AFVI_Info : NotifyPropertyChanged
    {
        /// <summary>   Gets or sets the identifier. </summary>
        /// <value> The identifier. </value>
        [XmlIgnore]
        public int Index
        {
            get
            {
                return m_nIndex;
            }
            set
            {
                m_nIndex = value;
                Notify("Index");
            }
        }

        /// <summary>   Gets or sets the MC Code. </summary>
        /// <value> The MC Code. </value>
        [XmlIgnore]
        public string Code
        {
            get
            {
                return m_strCode;
            }
            set
            {
                m_strCode = value;
                Notify("Code");
            }
        }

        /// <summary>   Gets or sets the Map Path. </summary>
        /// <value> The Map Path. </value>
        [XmlIgnore]
        public string Path
        {
            get
            {
                return m_strPath;
            }
            set
            {
                m_strPath = value;
                Notify("Path");
            }
        }

        private int m_nIndex = -1;
        private string m_strCode;
        private string m_strPath;
    }

    public class Customer: NotifyPropertyChanged
    {
        public string Code
        {
            get { return m_Code;}
            set
            {
                m_Code = value;
                Notify("Code");
            }
        }
        public int Type
        { 
            get { return m_Type; }
            set
            {
                m_Type = value;
                Notify("Type");
            }
        }

        private string m_Code;
        private int m_Type;
        public Customer(string code, int type)
        {
            Code = code;
            Type = type;
        }
    }

    public class RMV_Info : NotifyPropertyChanged
    {
        /// <summary>   Gets or sets the identifier. </summary>
        /// <value> The identifier. </value>
        [XmlIgnore]
        public int Index
        {
            get
            {
                return m_nIndex;
            }
            set
            {
                m_nIndex = value;
                Notify("Index");
            }
        }

        /// <summary>   Gets or sets the MC Code. </summary>
        /// <value> The MC Code. </value>
        [XmlIgnore]
        public string Code
        {
            get
            {
                return m_strCode;
            }
            set
            {
                m_strCode = value;
                Notify("Code");
            }
        }

        /// <summary>   Gets or sets the PLC IP. </summary>
        /// <value> The PLC IP. </value>
        [XmlIgnore]
        public string IP
        {
            get
            {
                return m_strIP;
            }
            set
            {
                m_strIP = value;
                Notify("IP");
            }
        }

        /// <summary>   Gets or sets the PLC Port. </summary>
        /// <value> The PLC Port. </value>
        /*  [XmlIgnore]
          public string Port
          {
              get
              {
                  return m_strPort;
              }
              set
              {
                  m_strPort = value;
                  Notify("Port");
              }
          }*/
        /// <summary>
        /// Gets or sets the PLC StationNumber
        /// .
        /// </summary>
        /// <value>The PLC StationNumber.</value>
        [XmlIgnore]
        public int StationNumber
        {
            get
            {
                return m_stationNumber;
            }
            set
            {
                m_stationNumber = value;
                Notify("StationNumber");
            }
        }
    

        private int m_nIndex = -1;
        private string m_strCode;
        private string m_strIP;
        //private string m_strPort;
        private int m_stationNumber;

    }
}
