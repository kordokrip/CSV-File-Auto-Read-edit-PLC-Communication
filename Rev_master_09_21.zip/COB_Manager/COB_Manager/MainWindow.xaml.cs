﻿using COB_Manager.Common;
using COB_Manager.Controls;
using PLC;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;


namespace COB_Manager
{
    // <summary>
    // MainWindow.xaml에 대한 상호 작용 논리
    // </summary>
    //Additional source code for PLC connection June 14
    public partial class MainWindow : Window
    {
        public static Information Info;
        private ModelInfo[] CurrModel = new ModelInfo[5];
        private FileCheck_Thread thd;
        private Thread PLC_Thd;
        AFVI_Status[] AFVI = new AFVI_Status[5];
        Controls.RMV_Info[] RMV = new Controls.RMV_Info[5];
        Order_Info[] Order = new Order_Info[5];
        MitsubiPlc PLC;
        bool Open = false;
        NotifyIcon trayIcon;
        private ObservableCollection<LotInfo> lstLotInfo = new ObservableCollection<LotInfo>();
        double orginalWidth, originalHeight; //Variation of object size according to window size
        ScaleTransform scale = new ScaleTransform();

        public MainWindow()
        {
            InitializeComponent();
            Init();
            InitEvent();
            ResizeMode = ResizeMode.CanResizeWithGrip;
            orginalWidth = this.Width;
            originalHeight = this.Height;
           

        }
    
   
        private void Init()
        {
            Info = new Information();
            AFVI[0] = MC1; AFVI[1] = MC2; AFVI[2] = MC3; AFVI[3] = MC4; AFVI[4] = MC5;
            RMV[0] = RMV01; RMV[1] = RMV02; RMV[2] = RMV03; RMV[3] = RMV04;
            Order[0] = Info1; Order[1] = Info2; Order[2] = Info3; Order[3] = Info4;
        }

        private void InitEvent()
        {
            this.Loaded += MainWindow_Loaded;
            this.KeyUp += MainWindow_KeyUp;
            this.Closing += MainWindow_Closing;
            this.btnClose.Click += BtnClose_Click;
            this.btnMin.Click += BtnMin_Click;
            this.IsVisibleChanged += MainWindow_IsVisibleChanged;
            this.txtInputBox.Focus();
            this.txtInputBox.KeyUp += TxtInputBox_KeyUp;
            this.txtInputBox.PreviewMouseUp += TxtInputBox_MouseUp;
   
        }
      

        private void TxtInputBox_MouseUp(object sender, MouseButtonEventArgs e)
        {
            txtInputBox.SelectAll();
        }

        private void TxtInputBox_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                CheckInputText();
            }
        }

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            trayIcon = new NotifyIcon();
            trayIcon.BalloonTipText = "COB Data Server 입니다";
            trayIcon.BalloonTipTitle = "COB DataServer";
            trayIcon.Text = "COB DataServer";
            trayIcon.Icon = new System.Drawing.Icon("../Images/icon.ico");
            trayIcon.Click += new EventHandler(trayIcon_Click);
        }

        void trayIcon_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = System.Windows.WindowState.Normal;
        }

        private void MainWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (IsVisible == false)
                trayIcon.Visible = true;
        }

        private void BtnMin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            trayIcon.ShowBalloonTip(2000);
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!ExitApplication())
                    e.Cancel = true;
        }

        public bool ExitApplication()
        {
            if (System.Windows.MessageBox.Show("프로그램을 종료하시겠습니까?", "종료", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                trayIcon.Icon = null;
                trayIcon.Visible = false;
                if (PLC_Thd != null)
                {
                    PLC_Thd.Abort();
                    Thread.Sleep(500);
                    PLC_Thd = null;
                }
                if (thd != null)
                {
                    thd.DisposeThread();
                }
                Environment.Exit(0);

                return true;
            }
            else return false;
        }
        private void MainWindow_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                Setting dlg = new Setting();
                if ((bool)dlg.ShowDialog())
                {
                    Info.Save();
                    InitDisplay();
                }
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Info.Load();
            InitDisplay();
            
            thd = new FileCheck_Thread(Info.AFVI, Info.InspDonePath, Info.EditPath,Info.MESPath, 10, Info.Customers);
            thd.LotInfoChanged += Thd_LotInfoChanged;
            if (Info.UsePLC)
            {
                Open = false;
                PLC_Thd = new Thread(GetPLC);
                PLC_Thd.Start();
            }
        }
      

        private void Thd_LotInfoChanged(ObservableCollection<LotInfo> lst)
        {
            Action a = delegate
            {
                lbLot.DataContext = lst;
            }; this.Dispatcher.Invoke(a);
        }

        public List<LotInfo> LoadLotList()
        {
            List<LotInfo> lst = new List<LotInfo>();
            string[] f = Directory.GetFiles(Info.EditPath);
            int n = 0;
            foreach (string name in f)
            {
                LotInfo l = new LotInfo(++n, name);
            }
            return lst;



        }
        private void CheckInputText()
        {
            string inputText = txtInputBox.Text.Trim();
            ObservableCollection<LotInfo> lst = lbLot.DataContext as ObservableCollection<LotInfo>;
            for (int i = 0; i< lst.Count; i++)
            {
                if(lst[i].LotNo == inputText)
                {
                    System.Windows.MessageBox.Show("연속불량 발생 편집요망", "RMV EDIT",MessageBoxButton.OK,MessageBoxImage.Exclamation,MessageBoxResult.Cancel);
                    return;
                }
               

            }
            System.Windows.MessageBox.Show("Q/A 의뢰 바랍니다.", "Q/A", MessageBoxButton.OK, MessageBoxImage.Asterisk, MessageBoxResult.Cancel);
        

        }
     

        void HideMe()
        {
            Thread.Sleep(2000);
            Action a = delegate
            {
                Hide();
                trayIcon.ShowBalloonTip(2000);
            }; this.Dispatcher.Invoke(a);
        }

        private void InitDisplay()
        {
            for (int i = 0; i < 5; i++)
            {
                AFVI[i].SetMCCode("");
                AFVI[i].SetStatus(false);
            }
            for (int i = 0; i < Info.AFVI.Count; i++)
            {
                AFVI[i].SetMCCode(Info.AFVI[i].Code);
            }
            for (int i = 0; i < 4; i++)
            {
                RMV[i].SetMCCode("");
                RMV[i].SetStatus(false);
            }
            for (int i = 0; i < Info.RMV.Count; i++)
            {
                RMV[i].SetMCCode(Info.RMV[i].Code);
            }
            //Display Initialize
            lbLot.DataContext = lstLotInfo;
        }

        private void GetPLC()
        {
            Action a;
            while (true)
            {
                for (int i=0; i< Info.RMV.Count; i++)
                {
                    PLC = new MitsubiPlc(0);
                    Open = PLC.ConnectPLC(Info.RMV[i].IP, Info.RMV[i].StationNumber);// Convert.ToInt32(Info.RMV[i].StationNumber));
                    a = delegate
                    {
                        RMV[i].SetStatus(Open);
                    }; this.Dispatcher.Invoke(a);
                    if (Open)
                    {
                        if (PLC.RequestJob())
                        {
                            a = delegate { RMV[i].SetJob(true); }; this.Dispatcher.Invoke(a);
                            ModelInfo mi;
                            try
                            {
                                mi = new ModelInfo();
                                mi.LotNo = PLC.ReadOrder();
                                int t = 0, g = 0, b = 0, j = 0;
                                PLC.ReadResult(ref t, ref g, ref b, ref j);
                                mi.GoodCount = g;
                                mi.BadCount = b;
                                mi.Joint = j;
                                mi.Total = t;
                                Counter_End(mi);
                                a = delegate { Order[i].UpdateData(mi); RMV[i].SetJob(false); }; this.Dispatcher.Invoke(a);
                                PLC.ClearJob();
                            }
                            catch { }
                           
                            
                        }
                       

                    }
                    PLC.Close();
                }
                Thread.Sleep(1000);
            }
        }

        private bool Counter_End(ModelInfo info)
        {
            string path = Info.EditPath + "\\"+ info.LotNo + ".csv";
            if (File.Exists(path))
            {
                try
                {
                    ModelInfo m = new ModelInfo(path, Info.Customers);
                    String new_path = path.Replace(Info.EditPath, Info.InspDonePath);
                    if (File.Exists(new_path))
                    {
                    if (File.Exists(Info.MESPath + "\\" + info.LotNo + ".txt"))
                    {
                        File.Delete(Info.MESPath + "\\" + info.LotNo + ".txt");
                        File.Delete(new_path);
                    }
                    File.Move(path, new_path);
                    }
                    FileStream fs = File.Create(Info.MESPath + "\\" + info.LotNo + ".txt");
                    fs.Close();
                    double length = (info.Total / m.Rows) * m.PF * 4.75 / 1000.0;
                    string str = info.GoodCount.ToString() + "\t" + info.BadCount.ToString() + "\t" + length.ToString("F2") + "\t" + info.Joint.ToString();
                    File.WriteAllText(Info.MESPath + "\\" + info.LotNo + ".txt", str);
                }
                catch (System.Exception ex)
                {
                    return false;
                }

            }

            return true;
        }

    }
}
