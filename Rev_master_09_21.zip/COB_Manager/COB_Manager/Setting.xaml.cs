﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using COB_Manager.Common;

namespace COB_Manager
{
    /// <summary>
    /// Setting.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Setting : Window
    {
        private Information info = new Information();
        public Setting()
        {
            InitializeComponent();
            InitEvent();
        }

        private void InitEvent()
        {
            this.Loaded += Setting_Loaded;
            this.btnSave.Click += BtnSave_Click;
            this.btnCancel.Click += BtnCancel_Click;
            this.btnSaveDonePath.Click += BtnSaveDonePath_Click;
            this.btnSaveEditPath.Click += BtnSaveEditPath_Click;
            this.btnAddAFVI.Click += BtnAddAFVI_Click;
            this.btnDelAFVI.Click += BtnDelAFVI_Click;
            this.btnAddRMV.Click += BtnAddRMV_Click;
            this.btnDelRMV.Click += BtnDelRMV_Click;
            this.btnAddCustomer.Click += BtnAddCustomer_Click;
            this.btnDelCustomer.Click += BtnDelCustomer_Click;
        }

        private void BtnDelCustomer_Click(object sender, RoutedEventArgs e)
        {
            string code = txtCustomerCode.Text.Trim();
            if (code == "") return;
            int id = -1;
            for (int i = 0; i < info.Customers.Count; i++)
            {
                if (info.Customers[i].Code == code)
                {
                    id = i;
                    break;
                }
            }
            if (id >= 0)
            {
                info.Customers.RemoveAt(id);
            }
        }

        private void BtnAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            string code = txtCustomerCode.Text.Trim();
            for (int i = 0; i < info.Customers.Count; i++)
            {
                if (info.Customers[i].Code == code)
                {
                    MessageBox.Show("이미 등록된 고객 입니다.");
                    return;
                }
            }
           
            try
            {
                Customer r = new Customer(txtCustomerCode.Text.Trim(), cbCustomerType.SelectedIndex);
                info.Customers.Add(r);
            }
            catch
            {
                MessageBox.Show("잘못된 정보가 있습니다.");
                return;
            }
            
        }

        private void BtnDelRMV_Click(object sender, RoutedEventArgs e)
        {
            string code = txtRMVCode.Text.Trim();
            if (code == "") return;
            int id = -1;
            for (int i = 0; i < info.RMV.Count; i++)
            {
                if (info.RMV[i].Code == code)
                {
                    id = i;
                    break;
                }
            }
            if (id >= 0)
            {
                info.RMV.RemoveAt(id);
                for (int i = 0; i < info.RMV.Count; i++)
                {
                    info.RMV[i].Index = i + 1;
                }
            }
        }

        private void BtnAddRMV_Click(object sender, RoutedEventArgs e)
        {
            string code = txtRMVCode.Text.Trim();
            for (int i = 0; i < info.RMV.Count; i++)
            {
                if (info.RMV[i].Code == code)
                {
                    MessageBox.Show("이미 등록된 설비 입니다.");
                    return;
                }
            }
            RMV_Info r = new RMV_Info();
            try
            {
                r.Index = info.RMV.Count + 1;
                r.Code = txtRMVCode.Text.Trim();
                r.IP = txtRMVIP.Text.Trim();
                //r.Port = txtRMVPort.Text.Trim();
                //r.StationNumber = txtRMVStationNumber.Text.Trim();
                //r.Status = txtRMVStatus.Text.Trim();
                //r.RJob = txtRMVRJob.Text.Trim();
                //r.PJob = txtRMVPJob.Text.Trim();
                //r.RDone = txtRMVRDone.Text.Trim();
                //r.PDone = txtRMVPDone.Text.Trim();
                //r.Order = txtRMVOrder.Text.Trim();
                //r.PF = txtRMVPF.Text.Trim();
                //r.Row = txtRMVRow.Text.Trim();
                //r.Count = txtRMVCount.Text.Trim();
            }
            catch
            {
                MessageBox.Show("잘못된 정보가 있습니다.");
                return;
            }
            info.RMV.Add(r);
        }

        private void BtnDelAFVI_Click(object sender, RoutedEventArgs e)
        {
            string code = txtAFVICode.Text.Trim();
            if (code == "") return;
            int id = -1;
            for (int i=0; i< info.AFVI.Count; i++)
            {
                if (info.AFVI[i].Code== code)
                {
                    id = i;
                    break;
                }
            }
            if (id >= 0)
            {
                info.AFVI.RemoveAt(id);
                for (int i = 0; i < info.AFVI.Count; i++)
                {
                    info.AFVI[i].Index = i + 1;
                }
            }
        }

        private void BtnAddAFVI_Click(object sender, RoutedEventArgs e)
        {
            string code = txtAFVICode.Text.Trim();
            for (int i = 0; i < info.AFVI.Count; i++)
            {
                if (info.AFVI[i].Code == code)
                {
                    MessageBox.Show("이미 등록된 설비 입니다.");
                    return;
                }
            }
            AFVI_Info a = new AFVI_Info();
            try { 
                a.Index = info.AFVI.Count + 1;
                a.Code = txtAFVICode.Text.Trim();
                a.Path = txtAFVIPath.Text.Trim();
            }
            catch
            {
                MessageBox.Show("잘못된 정보가 있습니다.");
                return;
            }
            info.AFVI.Add(a);
        }

        private void BtnSaveEditPath_Click(object sender, RoutedEventArgs e)
        {
            info.EditPath = this.txtEditPath.Text.Trim();
        }

        private void BtnSaveDonePath_Click(object sender, RoutedEventArgs e)
        {
            info.InspDonePath = this.txtDonePath.Text.Trim();
        }

        private void Setting_Loaded(object sender, RoutedEventArgs e)
        {
            info = MainWindow.Info.CopyTo();
            this.txtEditPath.Text = info.EditPath;
            this.txtDonePath.Text = info.InspDonePath;
            lbAFVI.DataContext = info.AFVI;
            lbRMV.DataContext = info.RMV;
            lbCustomer.DataContext = info.Customers;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.Info = new Information();
            MainWindow.Info = this.info.CopyTo();
            this.DialogResult = true;
        }
    }
}
