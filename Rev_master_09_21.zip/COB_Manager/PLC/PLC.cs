﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.Win32;
using ActUtlTypeLib;
using System.IO;




namespace PLC
{

    interface IMitsubiPlc
    {
        bool ConnectPLC(string ip, int StationNumber);
        int GetDevice(string szDeivce, out int lplData);
        int SetDevice(string szDeivce, int lData);
        int GetDeviceBlock(string szDevice, int nSize, out int lpdwData);
        int Write(string szDeivce, int nSize, ref int lpdwData);
        int WriteBuffer(int lStartIO, int lAddress, int lWriteSize, out short lpwData);
        int ReadBuffer(int lStartIO, int lAddress, int lWriteSize, out short lpwData);
        int Close();
    }

    /// <summary>   Mitsubi plc.  </summary>
    public class MitsubiPlc // : IPlcController 2012-04-24, Interface 삭제.
    {
        private IMitsubiPlc m_mitsubiPlc;
        private bool m_bOpen = false;
        private int m_Mode;
      


        #region  Ctor & Destructor.
        public MitsubiPlc(int mode)
        {
            if (mode == 0)
            {
                try
                {
                    m_mitsubiPlc = ActQJ71E71TCPDev.Instance();
                }
                catch (Exception ex)
                {
                    string[] str = ex.Message.Split('{', '}');
                  //  setReg64bit(str[1]);
                    Thread.Sleep(300);
                    m_mitsubiPlc = ActQJ71E71TCPDev.Instance();
                }
            }
            else
            {
                m_mitsubiPlc = ActQNUDECPUTCPDev.Instance();
            }
            m_Mode = mode;
        }

        ~MitsubiPlc()
        {
            // m_mitsubiPlc.Close();
        }
        #endregion

        public void setReg64bit(string regVal)
        {
            RegistryKey reg = Registry.ClassesRoot;
            RegistryKey reg1 = Registry.ClassesRoot;
            RegistryKey reg2 = Registry.LocalMachine;


            reg = reg.CreateSubKey("WOW6432Node\\CLSID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);
            reg.SetValue("AppID", "{" + regVal + "}", RegistryValueKind.String);
            reg.Flush();

            reg1 = reg1.CreateSubKey("WOW6432Node\\AppID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);
            reg1.SetValue("DllSurrogate", "", RegistryValueKind.String);
            reg1.Flush();

            reg2 = reg2.OpenSubKey("Software\\Classes\\AppID\\{" + regVal + "}", true);
            if (reg2 == null)
            {
                reg2 = Registry.LocalMachine.CreateSubKey("Software\\Classes\\AppID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);

            }
            reg.Close();
            reg2.Close();
        }

        public bool ConnectPLC(string ip, int StationNumber)
        {
            
            m_bOpen = m_mitsubiPlc.ConnectPLC(ip, StationNumber);
            //ActUtlTypeLib = new ActUtlTypeLib.ActMLUtlType();
            return m_bOpen;
        }

        public int Close()
        {
            return m_mitsubiPlc.Close();
        }


        public int ReadData(string astrAddress)
        {
            int lData = 0;
            return m_mitsubiPlc.GetDeviceBlock(astrAddress, 1, out lData);
            //return lData;
        }

        public int WriteData(string astrAddress, int val)
        {
            m_mitsubiPlc.Write(astrAddress, 1, ref val);
            return 0;
        }

        private bool ReadBit(string astrAddress)
        {
            int lData = 0;
            return m_mitsubiPlc.GetDevice(astrAddress, out lData) == 1 ? true:false;
            //return lData;
        }

        public bool RequestJob()
        {
            return ReadBit("M8000");
        }

        public void ClearJob()
        {
            m_mitsubiPlc.SetDevice("M8000", 0);
        }

        public string ReadOrder()
        {
            string s = "";
            char[] ch = new char[20];
            int id = 0;
            for (int i=0; i<10; i++)
            {
                int n = ReadData("R" + i.ToString());
                ch[id] = Convert.ToChar(n % 256);
                n = n >> 8;
                ch[++id] = Convert.ToChar(n);
                id++;
            }
            string ret = "";
            for (int i = 0; i < 20; i++)
            {
                if (ch[i] == ' ') continue;
                ret += ch[i];
            }
            
            return ret;

        }

        // 편집 완료 확인
        public void ReadResult(ref int total,ref int good, ref int bad, ref int joint)
        {
            int n;
            n = ReadData("R10");
            total = n;
            n = ReadData("R11");
            n = n << 16;
            total += n;
            n = ReadData("R12");
            good = n;
            n = ReadData("R13");
            n = n << 16;
            good += n;
            n = ReadData("R14");
            bad = n;
            n = ReadData("R15");
            n = n << 16;
            bad += n;
            n = ReadData("R16");
            joint = n;
            n = ReadData("R17");
            n = n << 16;
            joint += n;
        }

    }
}
