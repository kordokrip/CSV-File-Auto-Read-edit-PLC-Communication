﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace COB_Manager.Common
{
    public class FileCheck_Thread
    {
        private Thread CheckThd;
        private string SrcDir;
        private string InspDoneDir;
        private string EditDir;
        private int Wait;
        private bool Started;
        //Constructor
        //astrSrcDir             검사기 Map 경로
        //astrInspectDoneDir     편집이 없을 경우 복사 할 경로
        //astrEditPDir           편집이 있을 경우 복사 할 경로
        //anSleep                읽기 대기 시간 초
        public FileCheck_Thread(string astrSrcDir, string astrInspectDoneDir, string astrEditPDir, int anSleep)
        {
            Wait = anSleep;
            SrcDir = astrSrcDir;
            InspDoneDir = astrInspectDoneDir;
            EditDir = astrEditPDir;
            if (!Directory.Exists(InspDoneDir)) Directory.CreateDirectory(InspDoneDir);
            if (!Directory.Exists(EditDir)) Directory.CreateDirectory(EditDir);
            Thread.Sleep(1000);
            //1초 후 시작 한다
            CreateThread();
        }

        private void CreateThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
            CheckThd = new Thread(FileCheck);
            CheckThd.Start();

        }

        public void DispoceThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
        }

        private void FileCheck()
        {
            Started = true;
            int nCnt = Wait * 10;
            while (Started)
            {
                for (int i = 0; i < nCnt; i++)
                {
                    Thread.Sleep(100);
                    if (!Started) break;
                }
                if (Started)
                {
                    string[] files = Directory.GetFiles(SrcDir, "*.csv");
                    if (files.Length > 0)
                    {
                        foreach (string file in files)
                        {
                            EditCheck(file);
                        }
                    }
                }
            }
        }

        private bool EditCheck(string astrFile)
        {
            ModelInfo model = new ModelInfo(astrFile);
            if (model.FileLoaded)
            { 
                if (model.IsEdit())
                {
                    File.Move(astrFile, astrFile.Replace(SrcDir, EditDir));
                }
                else
                {
                    File.Move(astrFile, astrFile.Replace(SrcDir, InspDoneDir));
                }
            }
            return true;
        }
    }
}
