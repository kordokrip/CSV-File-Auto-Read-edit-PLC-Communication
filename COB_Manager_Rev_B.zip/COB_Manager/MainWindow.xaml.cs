﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using COB_Manager.Common;



namespace COB_Manager
{
    
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {

        private ModelInfo CurrModel;
        private FileCheck_Thread thd;
        public MainWindow()
        {
            InitializeComponent();
            InitEvent();
            
        }
   
        private void InitEvent()
        {
            
            this.btnFileOpen.Click += BtnFileOpen_Click;
            this.btnAutoRead.Click += BtnAutoRead_Click;
            this.Loaded += MainWindow_Loaded;
            
            //Code behind Button Click RaiseEvent
            //this.btnAutoRead.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, btnAutoRead));
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            btnAutoRead.Visibility = Visibility.Hidden;
            thd = new FileCheck_Thread("d:\\Mapdata", "d:\\InspectDone", "d:\\Edit", 1);
        }

        private void BtnAutoRead_Click(object sender, RoutedEventArgs e)
        {
            thd = new FileCheck_Thread("d:\\Mapdata", "d:\\InspectDone", "d:\\Edit", 1);
            //Button Hidden
            //btnAutoRead.Visibility = Visibility.Hidden;
        }

        private void BtnFileOpen_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.DefaultExt = ".csv";
            dlg.Filter = "csv Files (*.csv)|*.csv";
            dlg.InitialDirectory = "d:\\Mapdata";
            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string path = dlg.FileName;
                CurrModel = new ModelInfo(path, true);
                if (!CurrModel.FileLoaded)
                {
                    lblEdit.Content = "파일 읽기 실패";
                }
                else
                {
                    if (CurrModel.IsEdit()) lblEdit.Content = "편집 필요";
                    else lblEdit.Content = "편집 불필요";
                    grdModelInfo.DataContext = CurrModel;
                }
            }
        }

        private void btnAutoRead_Click_1(object sender, RoutedEventArgs e)
        {

        }
        
    }

}
