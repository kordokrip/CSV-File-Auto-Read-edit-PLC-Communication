﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ACTMULTILib;


//2018.03.12 오전11시41분 
/*
* 연결했을 떄 연결됨, 연결안됨 도 추가해야되고(여기엔 bool 함수 넣어서 어차피 시작할 떄는 연결안됬으니 bool a = 0; 으로 설정해주고 시작하면 되고
* 연결하기, 연결해제도 bool 원버튼으로 누르면 색바뀌게 하고 위에 Label 적어서 연결됨, 안됨 뜨게 하면 되고
 * Read, Write 블럭이나 비트들도 temp1값이 0이 아닌 다른값이면 오류코드니까 이거 오류메시지창에 띄워주는거 만들어야되고
 * 실시간으로 쓰레드 만들어서 while문 돌린다음에 PLC에서 값이 바뀌면 바뀌었다고 표시해주고(만드는중)
 * 쓰레드뺴고는 만들었는데 결국 쓰레드 해보려고 다시만들었네
 * 연결안되면 국번 설정한지 확인하고 mx 컴포넌트 실행됬는지 확인하고 안되있으면 gx works2 시뮬레이터 켜져있는지 확인하고 그래도 안되면 시뮬레이터 껏다키면 되요.
 * (지금 동작안하는 엉뚱한 시뮬레이터가 잡히기도함)
*/


namespace PLC_Thread_Test
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        ActEasyIF acteasyif;

        int temp1;
        string str2;
        int[] iData;
        char[] char_arr;
        int iData_length;
        string str1;
        string szDevice;
        string szDevice_d50;
        string szDevice_d200;
        int iData_bit;

        public MainWindow()
        {
            InitializeComponent();
            acteasyif = new ActEasyIF();
            acteasyif.ActLogicalStationNumber = 52; //국번 설정 

            iData_length = 5;
            iData = new int[iData_length];
            char_arr = new char[iData_length];
            Array.Clear(iData, 0, iData_length);
            str2 = "";
            szDevice = "x100";
            szDevice_d50 = "D50";
            szDevice_d200 = "D200";
            iData_bit = 1;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //    temp1 = acteasyif.Open();
            temp1 = acteasyif.Open();
            if (temp1 != 0)
            {
                label2.Content = "open에러 " + temp1;
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //2. 연결 해제하기.   버튼한개에 if문, bool + Label 사용하면 원버튼으로 연결, 해제 한번에 가능
        {
            acteasyif.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ID_Throw_Block();
        }

        private void ID_Throw_Block()         // WriteDeviceBlock     Textbox1에서 글자 긁어와서 char 변환 후 아스키코드로 변환해서 넣음. 
        {
            str1 = label1.Content.ToString();
            temp1 = 0;
            Array.Clear(iData, 0, iData_length);
            for (int i = 0; i < iData_length; i++)       //배열끝에는 null인지 0값이 강제로 들어가네. 
            {
                char_arr[i] = str1[i];
                iData[i] = Convert.ToInt32(char_arr[i]);
            }
            temp1 = acteasyif.WriteDeviceBlock(szDevice_d50, iData_length, ref iData[0]);

        }

        private void ID_Catch_Block() //ReadDeviceBlock   iData배열에서 값을 가져와서 가져온 값을 문자열로 만들고 라벨3에 출력.
        {
            temp1 = 0;
            Array.Clear(iData, 0, iData_length);
            temp1 = acteasyif.ReadDeviceBlock(szDevice_d200, iData_length, out iData[0]);

            if (temp1 != 0)         //비정상의 경우 0 이외의 숫자로 된 에러코드를 띄움.
            {
                label2.Content = "pc able 버튼 고장   " + temp1;
            }
            else if (temp1 == 0)        //정상동작
            {
                for (int i = 0; i < iData_length; i++)   //배열끝에는 null인지 0값이 강제로 들어가네.
                {

                    str2 += Convert.ToChar(iData[i]);

                }
                label3.Content = str2;
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e) //ThreadStart 
         {
                thread_Read();
         }
            private void thread_Read()
            {
                bool thread_start = true;
                while (thread_start)
                {
                    try
                    {

                    }
                    catch
                    {

                    }
                    finally
                    {

                    }
                }
            }
        
        private void ID_Throw_bit()
        {
            temp1 = 0;
            temp1 = acteasyif.SetDevice(szDevice, iData_bit);      //szDevice는 비트이름  X0을 조작하고 싶으면 X0을 바로 적어도 되고 변수로 넣어도 되고

            if (temp1 != 0)
            {
                label2.Content = "SetDevice 에러   " + temp1.ToString();
            }
            label6.Content = szDevice + " 신호 1" + " Set";
        }

        private void ID_Catch_bit()
        {
            temp1 = 0;
            temp1 = acteasyif.GetDevice(szDevice, out iData_bit);   //GetDevice     iData_bit는 PLC -> PC로 읽어온 값의 비트가 off(0)인지 on(1)인지

            if (temp1 != 0)
            {
                label2.Content = "GetDevice 에러   " + temp1.ToString();
            }
            label6.Content = szDevice + " 신호 " + iData_bit + " Get";
        }


        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            ID_Catch_Block();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            ID_Throw_bit();
        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            ID_Catch_bit();
        }
    }
}
