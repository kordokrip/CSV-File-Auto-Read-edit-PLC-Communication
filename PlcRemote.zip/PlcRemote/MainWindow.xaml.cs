﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

//https://kordokrip.visualstudio.com/_git/MyFirstProject

namespace PlcRemote
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        bool bPlcConnection = false;
        System.Timers.Timer _Timer;
        
        ActUtlTypeLib.ActUtlType _ActUtlType;
        ACTETHERLib.ActAJ71E71TCP _Enet;

        public MainWindow()
        {
            InitializeComponent();
        }

        //Timer 간격이 경과되면 발생될 내용
        void _Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (bPlcConnection.Equals(true))
            {
                String szDevice = "D0"; //읽어올 PLC Device
                int lSize = 1; //읽어올 PLC Device의 Word 수
                int[] lplData = new int[lSize]; //읽어온 PLC Device Word 값을 저장할 변수

                //_ActUtlType.ReadDeviceBlock 함수의 리턴 값
                int nResult = _ActUtlType.ReadDeviceBlock(szDevice, lSize, out lplData[0]);
                if (nResult.Equals(0)) //정상적으로 리턴받으면 0을 받는다.
                {
                    this.Dispatcher.Invoke(new D_Set_Value(_Set_Value), lplData[0]);
                }
            }
        }

        // PLC로 부터 읽은 데이터를 입력하기 위한 대리자
        private delegate void D_Set_Value(int nValue);
        private void _Set_Value(int nValue)
        {
            vConnectedText.Text = String.Format("Connected : {0}", nValue);
        }

        //PLC 연결 버튼
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _Timer = new System.Timers.Timer();
            _Timer.Interval = 100;
            _Timer.Elapsed += _Timer_Elapsed;
            _ActUtlType = new ActUtlTypeLib.ActUtlType();
            _Enet = new ACTETHERLib.ActAJ71E71TCP();
            _Enet.ActStationNumber = 0;
            _Enet.ActHostAddress = "192.12.1.1";


            //Logical Station number를 입력할 TextBox가 String.Empty이거나, Null이 아니면 진행되도록.
            if (String.IsNullOrEmpty(vPortNumber.Text).Equals(false))
            {
                _ActUtlType.ActLogicalStationNumber = Convert.ToInt32(vPortNumber.Text);
                if (_ActUtlType.Open().Equals(0))
                {
                    bPlcConnection = true;

                    //PLC의 M0를 접점시키는 코드
                    if (_ActUtlType.WriteDeviceBlock("M0", 1, 1).Equals(0)) 
                    {
                        _Timer.Start();
                    }
                }
            }
        }

        //PLC 연결 해제 버튼
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (bPlcConnection.Equals(true))
            {
                //PLC의 M0를 접점을 해제시키는 코드
                if (_ActUtlType.WriteDeviceBlock("M0", 1, 0).Equals(0))
                {
                    _Timer.Stop();
                    _Timer.Dispose();
                    _ActUtlType.Close();
                }
            }
        }
    }
}
