﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Drawing;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using COB_Manager.Common;
using COB_Manager.Controls;
using System.Threading;
using System.IO;
using PLC;

namespace COB_Manager
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        public static Information Info;
        private ModelInfo[] CurrModel = new ModelInfo[5];
        private FileCheck_Thread thd;
        private Thread PLC_Thd;
        AFVI_Status[] AFVI = new AFVI_Status[5];
        Controls.RMV_Info[] RMV = new Controls.RMV_Info[5];
        Order_Info[] Order = new Order_Info[5];
        MitsubiPlc[] PLC = new MitsubiPlc[5];
        bool[] Open = new bool[5];
        NotifyIcon trayIcon;
        public MainWindow()
        {
            InitializeComponent();
            Init();
            InitEvent();
        }

        private void Init()
        {
            Info = new Information();
            AFVI[0] = MC1; AFVI[1] = MC2; AFVI[2] = MC3; AFVI[3] = MC4; AFVI[4] = MC5;
            RMV[0] = RMV01; RMV[1] = RMV02; RMV[2] = RMV03; RMV[3] = RMV04; RMV[4] = RMV05;
            Order[0] = Info1; Order[1] = Info2; Order[2] = Info3; Order[3] = Info4; Order[4] = Info5;
        }

        private void InitEvent()
        {
            this.Loaded += MainWindow_Loaded;
            this.KeyUp += MainWindow_KeyUp;
            this.Closing += MainWindow_Closing;
            this.btnClose.Click += BtnClose_Click;
            this.btnMin.Click += BtnMin_Click;
            this.IsVisibleChanged += MainWindow_IsVisibleChanged;
        }

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            trayIcon = new NotifyIcon();
            trayIcon.BalloonTipText = "COB Data Server 입니다";
            trayIcon.BalloonTipTitle = "COB DataServer";
            trayIcon.Text = "COB DataServer";
            trayIcon.Icon = new System.Drawing.Icon("../Images/icon.ico");
            trayIcon.Click += new EventHandler(trayIcon_Click);
        }

        void trayIcon_Click(object sender, EventArgs e)
        {
            Show();
            WindowState = System.Windows.WindowState.Normal;
        }

        private void MainWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (IsVisible == false)
                trayIcon.Visible = true;
        }

        private void BtnMin_Click(object sender, RoutedEventArgs e)
        {
            Hide();
            trayIcon.ShowBalloonTip(2000);
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!ExitApplication())
                    e.Cancel = true;
        }

        public bool ExitApplication()
        {
            if (System.Windows.MessageBox.Show("프로그램을 종료하시겠습니까?", "종료", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                trayIcon.Icon = null;
                trayIcon.Visible = false;
                if (PLC_Thd != null)
                {
                    PLC_Thd.Abort();
                    Thread.Sleep(500);
                    PLC_Thd = null;
                }
                if (thd != null)
                {
                    thd.DisposeThread();
                }
                Environment.Exit(0);

                return true;
            }
            else return false;
        }
        private void MainWindow_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.F1)
            {
                Setting dlg = new Setting();
                if ((bool)dlg.ShowDialog())
                {
                    Info.Save();
                    InitDisplay();
                }
            }
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            Info.Load();
            InitDisplay();
            for (int i = 0; i < 5; i++) Open[i] = false;
            for (int i=0;i<Info.RMV.Count; i++)
            {
                PLC[i] = new MitsubiPlc(0);
                Open[i] = PLC[i].ConnectPLC(Info.RMV[i].IP, Convert.ToInt32(Info.RMV[i].Port));
                RMV[i].SetStatus(Open[i]);
            }
          //  thd = new FileCheck_Thread(Info.AFVI, Info.InspDonePath, Info.EditPath, 1000);
           // PLC_Thd = new Thread(GetPLC);
           // PLC_Thd.Start();
        }
        void HideMe()
        {
            Thread.Sleep(2000);
            Action a = delegate
            {
                Hide();
                trayIcon.ShowBalloonTip(2000);
            }; this.Dispatcher.Invoke(a);
        }

        private void InitDisplay()
        {
            for (int i = 0; i < 5; i++)
            {
                AFVI[i].SetMCCode("");
                AFVI[i].SetStatus(false);
            }
            for (int i = 0; i < Info.AFVI.Count; i++)
            {
                AFVI[i].SetMCCode(Info.AFVI[i].Code);
            }
            for (int i = 0; i < 5; i++)
            {
                RMV[i].SetMCCode("");
                RMV[i].SetStatus(false);
            }
            for (int i = 0; i < Info.RMV.Count; i++)
            {
                RMV[i].SetMCCode(Info.RMV[i].Code);
            }
            //Display Initialize

        }

        private bool GetOrder(string order, int Index)
        {
            string[] files = Directory.GetFiles(Info.EditPath);
            bool isValide = false;
            string path = "";
            foreach(string f in files)
            {
                if (f.Contains(order))
                {
                    isValide = true;
                    path = f;
                    break;
                }
            }
            if (isValide)
            {
                CurrModel[Index] = new ModelInfo(path, true);
                return true;
            }
            else return false;
        }

        private void GetPLC()
        {
            Action a;
            while (true)
            {
                for (int i=0; i< Info.RMV.Count; i++)
                {
                    if (Open[i])
                    {
                        if (PLC[i].AutoMode(Info.RMV[i].Status))
                        {
                            a = delegate { RMV[i].SetStatus(true); };
                            this.Dispatcher.Invoke(a);
                        }
                        else
                        {
                            a = delegate { RMV[i].SetStatus(false); };
                            this.Dispatcher.Invoke(a);
                        }

                        if (PLC[i].RequestJob(Info.RMV[i].RJob))
                        {
                            a = delegate { RMV[i].SetJob(true); };
                            this.Dispatcher.Invoke(a);
                            string order = PLC[i].ReadOrder(Info.RMV[i].Order);
                            if (GetOrder(order, i))
                            {
                                PLC[i].SendOrderData(CurrModel[i].PF, CurrModel[i].Rows, CurrModel[i].TotalCount, CurrModel[i].ReelMap, Info.RMV[i].PF, Info.RMV[i].Row, Info.RMV[i].Count, Info.RMV[i].Map, Info.RMV[i].PJob);
                            }
                            else
                            {
                                PLC[i].SendOrderData(CurrModel[i].PF, CurrModel[i].Rows, 0, null, Info.RMV[i].PF, Info.RMV[i].Row, Info.RMV[i].Count, Info.RMV[i].Map, Info.RMV[i].PJob);
                            }
                            /// PLC에서 오더를 읽어온다
                            /// PLC에 Map 및 정보를 보내준다.
                        }
                        else
                        {
                            a = delegate { RMV[i].SetJob(false); };
                            this.Dispatcher.Invoke(a);
                        }

                        if (PLC[i].RequestDone(Info.RMV[i].RDone))
                        {
                            a = delegate { RMV[i].SetDone(true); };
                            this.Dispatcher.Invoke(a);
                            //결과 읽어 올것
                            //Where is PLC result 
                        }
                        else
                        {
                            a = delegate { RMV[i].SetDone(false); };
                            this.Dispatcher.Invoke(a);
                        }

                    }
                }
                Thread.Sleep(1000);
            }
        }

        private void RMV01_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
