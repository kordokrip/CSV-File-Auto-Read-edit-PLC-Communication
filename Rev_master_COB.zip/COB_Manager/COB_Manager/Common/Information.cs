﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using System.Collections.ObjectModel;
using System.IO;

namespace COB_Manager.Common
{
    public class Information
    {
        public string EditPath;
        public string InspDonePath;
        public ObservableCollection<RMV_Info> RMV = new ObservableCollection<RMV_Info>();
        public ObservableCollection<AFVI_Info> AFVI = new ObservableCollection<AFVI_Info>();
        private string m_path = Environment.CurrentDirectory + "\\..\\config\\Info.ini";

        public bool Load()
        {
            if (!File.Exists(m_path)) File.Create(m_path);
            IniFile ini = new IniFile(m_path);
            EditPath = ini.ReadString("PATH", "EDITPATH", "d:\\edit");
            InspDonePath = ini.ReadString("PATH", "INSPDONEPATH", "d:\\inspdone");
            int cnt = ini.ReadInteger("AFVI", "COUNT", 0);
            AFVI.Clear();
            for (int i = 0; i < cnt; i++)
            {
                AFVI_Info r = new AFVI_Info();
                r.Index = i + 1;
                r.Code = ini.ReadString("AFVI", "CODE" + (i+1).ToString(), "");
                r.Path = ini.ReadString("AFVI", "PATH" + (i + 1).ToString(), "");
                AFVI.Add(r);
            }
            cnt = ini.ReadInteger("RMV", "COUNT", 0);
            RMV.Clear();
            for (int i = 0; i < cnt; i++)
            {
                RMV_Info r = new RMV_Info();
                r.Index = i + 1;
                r.Code = ini.ReadString("RMV", "CODE" + (i + 1).ToString(), "");
                r.IP = ini.ReadString("RMV", "IP" + (i + 1).ToString(), "");
                r.Port = ini.ReadString("RMV", "PORT" + (i + 1).ToString(), "");
                r.Status = ini.ReadString("RMV", "STATUS" + (i + 1).ToString(), "");
                r.RJob = ini.ReadString("RMV", "RJOB" + (i + 1).ToString(), "");
                r.PJob = ini.ReadString("RMV", "PJOB" + (i + 1).ToString(), "");
                r.RDone = ini.ReadString("RMV", "RDONE" + (i + 1).ToString(), "");
                r.PDone = ini.ReadString("RMV", "PDONE" + (i + 1).ToString(), "");
                r.Order = ini.ReadString("RMV", "ORDER" + (i + 1).ToString(), "");
                r.Count = ini.ReadString("RMV", "COUNT" + (i + 1).ToString(), "");
                r.PF = ini.ReadString("RMV", "PF" + (i + 1).ToString(), "");
                r.Map = ini.ReadString("RMV", "MAP" + (i + 1).ToString(), "");
                r.Row = ini.ReadString("RMV", "ROW" + (i + 1).ToString(), "");
                RMV.Add(r);
            }
            return true;
        }

        public bool Save()
        {
            if (!File.Exists(m_path)) File.Create(m_path);
            IniFile ini = new IniFile(m_path);
            ini.WriteString("PATH", "EDITPATH", EditPath);
            ini.WriteString("PATH", "INSPDONEPATH", InspDonePath);
            int cnt = AFVI.Count;
            ini.WriteInteger("AFVI", "COUNT", cnt);
            for (int i = 0; i < cnt; i++)
            {
                ini.WriteString("AFVI", "CODE" + (i + 1).ToString(), AFVI[i].Code);
                ini.WriteString("AFVI", "PATH" + (i + 1).ToString(), AFVI[i].Path);
            }
            cnt = RMV.Count;
            ini.WriteInteger("RMV", "COUNT", cnt); 
            for (int i = 0; i < cnt; i++)
            {
                ini.WriteString("RMV", "CODE" + (i + 1).ToString(), RMV[i].Code);
                ini.WriteString("RMV", "IP" + (i + 1).ToString(), RMV[i].IP);
                ini.WriteString("RMV", "PORT" + (i + 1).ToString(), RMV[i].Port);
                ini.WriteString("RMV", "STATUS" + (i + 1).ToString(), RMV[i].Status);
                ini.WriteString("RMV", "RJOB" + (i + 1).ToString(), RMV[i].RJob);
                ini.WriteString("RMV", "PJOB" + (i + 1).ToString(), RMV[i].PJob);
                ini.WriteString("RMV", "RDONE" + (i + 1).ToString(), RMV[i].RDone);
                ini.WriteString("RMV", "PDONE" + (i + 1).ToString(), RMV[i].PDone);
                ini.WriteString("RMV", "ORDER" + (i + 1).ToString(), RMV[i].Order);
                ini.WriteString("RMV", "COUNT" + (i + 1).ToString(), RMV[i].Count);
                ini.WriteString("RMV", "PF" + (i + 1).ToString(), RMV[i].PF);
                ini.WriteString("RMV", "MAP" + (i + 1).ToString(), RMV[i].Map);
                ini.WriteString("RMV", "ROW" + (i + 1).ToString(), RMV[i].Row);
            }
            return true;
        }

        public Information CopyTo()
        {
            Information info = new Information();
            info.EditPath = this.EditPath;
            info.InspDonePath = this.InspDonePath;
            for (int i = 0; i < this.AFVI.Count; i++)
            {
                AFVI_Info a = new AFVI_Info();
                a.Index = this.AFVI[i].Index;
                a.Code = this.AFVI[i].Code;
                a.Path = this.AFVI[i].Path;
                info.AFVI.Add(a);
            }
            for (int i = 0; i < this.RMV.Count; i++)
            {
                RMV_Info a = new RMV_Info();
                a.Index = this.RMV[i].Index;
                a.Code = this.RMV[i].Code;
                a.IP = this.RMV[i].IP;
                a.Port = this.RMV[i].Port;
                a.Status = this.RMV[i].Status;
                a.RJob = this.RMV[i].RJob;
                a.PJob = this.RMV[i].PJob;
                a.RDone = this.RMV[i].RDone;
                a.PDone = this.RMV[i].PDone;
                a.Order = this.RMV[i].Order;
                a.PF = this.RMV[i].PF;
                a.Count = this.RMV[i].Count;
                a.Map = this.RMV[i].Map;
                a.Row = this.RMV[i].Row;
                info.RMV.Add(a);
            }
            return info;
        }
    }

    public class AFVI_Info : NotifyPropertyChanged
    {
        /// <summary>   Gets or sets the identifier. </summary>
        /// <value> The identifier. </value>
        [XmlIgnore]
        public int Index
        {
            get
            {
                return m_nIndex;
            }
            set
            {
                m_nIndex = value;
                Notify("Index");
            }
        }

        /// <summary>   Gets or sets the MC Code. </summary>
        /// <value> The MC Code. </value>
        [XmlIgnore]
        public string Code
        {
            get
            {
                return m_strCode;
            }
            set
            {
                m_strCode = value;
                Notify("Code");
            }
        }

        /// <summary>   Gets or sets the Map Path. </summary>
        /// <value> The Map Path. </value>
        [XmlIgnore]
        public string Path
        {
            get
            {
                return m_strPath;
            }
            set
            {
                m_strPath = value;
                Notify("Path");
            }
        }

        private int m_nIndex = -1;
        private string m_strCode;
        private string m_strPath;
    }

    public class RMV_Info : NotifyPropertyChanged
    {
        /// <summary>   Gets or sets the identifier. </summary>
        /// <value> The identifier. </value>
        [XmlIgnore]
        public int Index
        {
            get
            {
                return m_nIndex;
            }
            set
            {
                m_nIndex = value;
                Notify("Index");
            }
        }

        /// <summary>   Gets or sets the MC Code. </summary>
        /// <value> The MC Code. </value>
        [XmlIgnore]
        public string Code
        {
            get
            {
                return m_strCode;
            }
            set
            {
                m_strCode = value;
                Notify("Code");
            }
        }

        /// <summary>   Gets or sets the PLC IP. </summary>
        /// <value> The PLC IP. </value>
        [XmlIgnore]
        public string IP
        {
            get
            {
                return m_strIP;
            }
            set
            {
                m_strIP = value;
                Notify("IP");
            }
        }

        /// <summary>   Gets or sets the PLC Port. </summary>
        /// <value> The PLC Port. </value>
        [XmlIgnore]
        public string Port
        {
            get
            {
                return m_strPort;
            }
            set
            {
                m_strPort = value;
                Notify("Port");
            }
        }

        /// <summary>   Gets or sets the PLC Address Status. </summary>
        /// <value> The PLC Address Status. </value>
        [XmlIgnore]
        public string Status
        {
            get
            {
                return m_strStatus;
            }
            set
            {
                m_strStatus = value;
                Notify("Status");
            }
        }

        /// <summary>   Gets or sets the PLC Address Request Job. </summary>
        /// <value> The PLC Address Request Job. </value>
        [XmlIgnore]
        public string RJob
        {
            get
            {
                return m_strRJob;
            }
            set
            {
                m_strRJob = value;
                Notify("RJob");
            }
        }

        /// <summary>   Gets or sets the PLC Address Request RMV Done. </summary>
        /// <value> The PLC Address Request RMV Done. </value>
        [XmlIgnore]
        public string RDone
        {
            get
            {
                return m_strRDone;
            }
            set
            {
                m_strRDone = value;
                Notify("RDone");
            }
        }

        /// <summary>   Gets or sets the PLC Address Pass RMV Job. </summary>
        /// <value> The PLC Address Pass RMV Job. </value>
        [XmlIgnore]
        public string PJob
        {
            get
            {
                return m_strPJob;
            }
            set
            {
                m_strPJob = value;
                Notify("PJob");
            }
        }

        /// <summary>   Gets or sets the PLC Address Pass RMV Done. </summary>
        /// <value> The PLC Address Pass RMV Done. </value>
        [XmlIgnore]
        public string PDone
        {
            get
            {
                return m_strPDone;
            }
            set
            {
                m_strPDone = value;
                Notify("PDone");
            }
        }

        /// <summary>   Gets or sets the PLC Address Get RMV Order. </summary>
        /// <value> The PLC Address Get RMV Order. </value>
        [XmlIgnore]
        public string Order
        {
            get
            {
                return m_strOrder;
            }
            set
            {
                m_strOrder = value;
                Notify("Order");
            }
        }

        /// <summary>   Gets or sets the PLC Address Set RMV PF. </summary>
        /// <value> The PLC Address Set RMV PF. </value>
        [XmlIgnore]
        public string PF
        {
            get
            {
                return m_strPF;
            }
            set
            {
                m_strPF = value;
                Notify("PF");
            }
        }

        /// <summary>   Gets or sets the PLC Address Set RMV Row. </summary>
        /// <value> The PLC Address Set RMV Row. </value>
        [XmlIgnore]
        public string Row
        {
            get
            {
                return m_strRow;
            }
            set
            {
                m_strRow = value;
                Notify("Row");
            }
        }

        /// <summary>   Gets or sets the PLC Address Set RMV Count. </summary>
        /// <value> The PLC Address Set RMV Count. </value>
        [XmlIgnore]
        public string Count
        {
            get
            {
                return m_strCount;
            }
            set
            {
                m_strCount = value;
                Notify("Count");
            }
        }

        /// <summary>   Gets or sets the PLC Address Set RMV Map. </summary>
        /// <value> The PLC Address Set RMV Map. </value>
        [XmlIgnore]
        public string Map
        {
            get
            {
                return m_strMap;
            }
            set
            {
                m_strMap = value;
                Notify("Map");
            }
        }

        private int m_nIndex = -1;
        private string m_strCode;
        private string m_strIP;
        private string m_strPort;
        private string m_strStatus;
        private string m_strRJob;
        private string m_strPJob;
        private string m_strRDone;
        private string m_strPDone;
        private string m_strOrder;
        private string m_strPF;
        private string m_strCount;
        private string m_strMap;
        private string m_strRow;
    }
}
