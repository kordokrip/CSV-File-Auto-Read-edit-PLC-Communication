﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Linq;
using System.Text;
using System.IO;

namespace COB_Manager.Common
{
    public class ModelInfo : NotifyPropertyChanged
    {
        #region Properties.
        /// <summary>   Gets or sets the ModelName. </summary>
        /// <value> The ModelName. </value>
        [XmlIgnore]
        public string ModelName
        {
            get
            {
                return m_strModelName;
            }
            set
            {
                m_strModelName = value;
                Notify("ModelName");
            }
        }

        /// <summary>   Gets or sets the LotNo. </summary>
        /// <value> The LotNo. </value>
        [XmlIgnore]
        public string LotNo
        {
            get
            {
                return m_strLotNo;
            }
            set
            {
                m_strLotNo = value;
                Notify("LotNo");
            }
        }

        /// <summary>   Gets or sets the Customer. </summary>
        /// <value> The Customer. </value>
        [XmlIgnore]
        public string Customer
        {
            get
            {
                return m_strCustomer;
            }
            set
            {
                m_strCustomer = value;
                Notify("Customer");
            }
        }

        /// <summary>   Gets or sets the Rows. </summary>
        /// <value> The Rows. </value>
        [XmlIgnore]
        public int Rows
        {
            get
            {
                return m_nRows;
            }
            set
            {
                m_nRows = value;
                Notify("Rows");
            }
        }


        /// <summary>   Gets or sets the PF. </summary>
        /// <value> The PF. </value>
        [XmlIgnore]
        public int PF
        {
            get
            {
                return m_nPF;
            }
            set
            {
                m_nPF = value;
                Notify("PF");
            }
        }

        /// <summary>   Gets or sets the TotalCount. </summary>
        /// <value> The TotalCount. </value>
        [XmlIgnore]
        public int TotalCount
        {
            get
            {
                return m_nTotalCount;
            }
            set
            {
                m_nTotalCount = value;
                Notify("TotalCount");
            }
        }

        /// <summary>   Gets or sets the BadCount. </summary>
        /// <value> The BadCount. </value>
        [XmlIgnore]
        public int BadCount
        {
            get
            {
                return m_nBadCount;
            }
            set
            {
                m_nBadCount = value;
                Notify("BadCount");
            }
        }

        /// <summary>   Gets or sets the Yield. </summary>
        /// <value> The Yield. </value>
        [XmlIgnore]
        public double Yield
        {
            get
            {
                return 100.00 - ((double)m_nBadCount / (double)m_nTotalCount) * 100.00;
            }
        }

        /// <summary>   Gets or sets the StartTime. </summary>
        /// <value> The StartTime. </value>
        [XmlIgnore]
        public DateTime StartTime
        {
            get
            {
                return m_dtStart;
            }
            set
            {
                m_dtStart = value;
                Notify("StartTime");
            }
        }

        /// <summary>   Gets or sets the StartTime. </summary>
        /// <value> The StartTime. </value>
        [XmlIgnore]
        public DateTime EndTime
        {
            get
            {
                return m_dtEnd;
            }
            set
            {
                m_dtEnd = value;
                Notify("EndTime");
            }
        }

        #endregion Properties.

        public bool[,] ReelMap;

        #region Private member variables.
        private string m_strModelName;
        private string m_strLotNo;
        private string m_strCustomer;
        private int m_nRows;
        private int m_nPF;
        private int m_nTotalCount;
        private int m_nBadCount;
        private int m_nColumn;
        private DateTime m_dtStart;
        private DateTime m_dtEnd;
        #endregion Private member variables.

        public bool FileLoaded;

        #region Function

        //Default Constructor.
        public ModelInfo()
        {
        }

        //File Constructor.
        //astrFilePath is ReelMap File Full Path and File Name.
        //bReadMap is Reading ReelMap Flags. Default False.
        public ModelInfo(string astrFilePath, bool bReadMap = false)
        {
            StreamReader file;
            try
            {
                file = new StreamReader(astrFilePath, Encoding.Default);
            }
            catch
            {
                FileLoaded = false;
                return;
            }
            string line;
            bool bEndRead = false;
            try
            {
                while (!bEndRead)
                {
                    line = file.ReadLine();
                    if (line == null) break;
                    string[] sp = line.Split(',');
                    if (sp.Length < 1) continue;
                    try
                    {
                        switch (sp[0])
                        {
                            case "모델명": this.ModelName = sp[1]; break;
                            case "Lot No": this.LotNo = sp[1]; break;
                            case "고객코드": this.Customer = sp[1]; break;
                            case "PF": this.PF = Convert.ToInt32(sp[1]); break;
                            case "열수":
                                this.Rows = Convert.ToInt32(sp[1]);
                                if (!bReadMap) bEndRead = true;
                                else
                                {
                                    m_nColumn = this.TotalCount / Rows;
                                    List<string> Maps = new List<string>();
                                    file.ReadLine();
                                    while (true)
                                    {
                                        string map = file.ReadLine();
                                        if (map == null) break;
                                        if (map.Contains("TOP")) break;
                                        Maps.Add(map);
                                    }
                                    MapParse(Maps);
                                    bEndRead = true;
                                }
                                break;
                            case "검사수": this.TotalCount = Convert.ToInt32(sp[1]); break;
                            case "NG수": this.BadCount = Convert.ToInt32(sp[1]); break;
                            case "검사 시작시간": this.StartTime = Convert.ToDateTime(sp[1]); break;
                            case "검사 종료시간": this.EndTime = Convert.ToDateTime(sp[1]); break;
                        }
                    }
                    catch
                    {
                    }
                }
            }
            catch
            {
                FileLoaded = false;
            }
            finally
            {
                file.Close();
            }
            FileLoaded = true;
        }
           
        // MapParse 
        private void MapParse(List<string> lstMap)
        {
           
            this.ReelMap = new bool[Rows, m_nColumn];
            int k = 0;
            for (int i = 0; i < lstMap.Count-1; i++)
            {
                for (int j = 0; j < Rows; j++)
                { 
                    string[] sp = lstMap[i].Split(',');
                    if (sp.Length > 1)
                    {
                        for (int n = 1; n < Math.Min(sp.Length, 51); n++)
                        {
                            if (sp[n] == "") break; 
                            this.ReelMap[j, (k * 50) + n - 1] = (sp[n] == "G") ? true : false;
                        }
                    }
                    i++;
                }
                i--;
                k++;
            }
        }

        public bool IsEdit()
        {
            switch (this.Customer)
            {
                case "SS00":
                    int ncnt1 = 0;
                    int ncnt2 = 0;
                    for (int i = 0; i < m_nColumn; i++)
                    {
                        int nBad = 0;
                        for (int j = 0; j < Rows; j++)
                        {
                            if (!this.ReelMap[j, i]) nBad++;
                        }
                        if (nBad == Rows) ncnt2++; else ncnt2 = 0;
                        if (ncnt2 >= 4) return true;
                        if (nBad > 0) ncnt1++;
                        else ncnt1 = 0;
                        if (ncnt1 >= 8) return true;
                    }
                    break;
                case "SS01":
                    int[] cnt = new int[this.Rows];
                    for (int i = 0; i < Rows; i++) cnt[i] = 0;
                    for (int i = 0; i < m_nColumn; i++)
                    {
                        for (int j = 0; j < Rows; j++)
                        {
                            if (!this.ReelMap[j, i]) cnt[j]++;
                            else cnt[j] = 0;
                            if (cnt[j] > 6) return true;
                        }
                    }
                    break;
            }
            return false;
        }
        #endregion
    }


    #region Notify Event
    /// <summary>   Notify property changed.  </summary>
    /// <remarks>   suoow2, 2014-10-25. </remarks>
    [Serializable]
    public class NotifyPropertyChanged : INotifyPropertyChanged
    {
        /// <summary> Event queue for all listeners interested in PropertyChanged events. </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>   Notifies. </summary>
        /// <remarks>   suoow2, 2014-08-09. </remarks>
        /// <param name="strPropertyName">  Name of the property. </param>
        public void Notify(string strPropertyName)
        {
            PropertyChangedEventHandler p = PropertyChanged;
            if (p != null)
            {
                p(this, new PropertyChangedEventArgs(strPropertyName));
            }
        }
    }
    #endregion Notify Event
}
