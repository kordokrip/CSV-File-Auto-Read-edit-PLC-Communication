﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace COB_Manager.Common
{
    public class FileCheck_Thread
    {
        private Thread CheckThd;
        private string[] SrcDir;
        private string InspDoneDir;
        private string EditDir;
        private int Wait;
        private bool Started;
        //Constructor
        //astrSrcDir             검사기 Map 경로
        //astrInspectDoneDir     편집이 없을 경우 복사 할 경로
        //astrEditPDir           편집이 있을 경우 복사 할 경로
        //anSleep                읽기 대기 시간 초
        public FileCheck_Thread(ObservableCollection<AFVI_Info> afvi, string astrInspectDoneDir, string astrEditPDir, int anSleep)
        {
            Wait = anSleep;
            SrcDir = new string[afvi.Count];
            for (int i = 0; i < afvi.Count; i++)
            {
                SrcDir[i] = afvi[i].Path;
            }
            InspDoneDir = astrInspectDoneDir;
            EditDir = astrEditPDir;
            try
            {
                if (!Directory.Exists(InspDoneDir)) Directory.CreateDirectory(InspDoneDir);
                if (!Directory.Exists(EditDir)) Directory.CreateDirectory(EditDir);
            }
            catch
            {
                return;
            }
            Thread.Sleep(1000);
            //1초 후 시작 한다
            CreateThread();
        }

        private void CreateThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
            CheckThd = new Thread(FileCheck);
            CheckThd.Start();
        }

        public void DisposeThread()
        {
            if (CheckThd != null)
            {
                Started = false;
                CheckThd.Abort();
                CheckThd = null;
            }
        }

        private void FileCheck()
        {
            Started = true;
            int nCnt = Wait * 10;
            while (Started)
            {
                for (int i = 0; i < nCnt; i++)
                {
                    Thread.Sleep(100);
                    if (!Started) break;
                }
                if (Started)
                {
                    for (int i = 0; i < SrcDir.Length; i++)
                    {
                        string[] files = Directory.GetFiles(SrcDir[i], "*.csv");
                        if (files.Length > 0)
                        {
                            foreach (string file in files)
                            {
                                EditCheck(file, SrcDir[i]);
                            }
                        }
                    }
                }
            }
        }

        private bool EditCheck(string astrFile, string path)
        {
            ModelInfo model = new ModelInfo(astrFile);
            if (model.FileLoaded)
            { 
                if (model.IsEdit())
                {
                    File.Move(astrFile, astrFile.Replace(path, EditDir));
                }
                else
                {
                    File.Move(astrFile, astrFile.Replace(path, InspDoneDir));
                }
            }
            return true;
        }
    }
}
