﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace COB_Manager.Controls
{
    /// <summary>
    /// RMV_Info.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class RMV_Info : UserControl
    {
        private const string imgON = "../Images/GD.png";
        private const string imgOFF = "../Images/NA.png";
        public RMV_Info()
        {
            InitializeComponent();
        }

        public void SetMCCode(string astrCode)
        {
            lblMCCode.Content = astrCode;
        }

        public void SetStatus(bool bConnected)
        {
            try
            {
                BitmapImage bi3 = new BitmapImage();
                bi3.BeginInit();
                if (bConnected)
                    bi3.UriSource = new Uri(imgON, UriKind.Relative);
                else
                    bi3.UriSource = new Uri(imgOFF, UriKind.Relative);
                bi3.EndInit();
                this.imgOnOff.Source = bi3;
            }
            catch { }
        }
        public void SetJob(bool bConnected)
        {
            try
            {
                BitmapImage bi3 = new BitmapImage();
                bi3.BeginInit();
                if (bConnected)
                    bi3.UriSource = new Uri(imgON, UriKind.Relative);
                else
                    bi3.UriSource = new Uri(imgOFF, UriKind.Relative);
                bi3.EndInit();
                this.imgJob.Source = bi3;
            }
            catch { }
        }

        public void SetDone(bool bConnected)
        {
            try
            {
                BitmapImage bi3 = new BitmapImage();
                bi3.BeginInit();
                if (bConnected)
                    bi3.UriSource = new Uri(imgON, UriKind.Relative);
                else
                    bi3.UriSource = new Uri(imgOFF, UriKind.Relative);
                bi3.EndInit();
                this.imgDone.Source = bi3;
            }
            catch { }
        }
    }
}
