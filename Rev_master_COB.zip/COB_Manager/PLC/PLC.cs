﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace PLC
{
    interface IMitsubiPlc
    {
        bool ConnectPLC(string ip, int port);
        int GetDevice(string szDeivce, out int lplData);
        int SetDevice(string szDeivce, int lData);
        int GetDeviceBlock(string szDevice, int nSize, out int lpdwData);
        int Write(string szDeivce, int nSize, ref int lpdwData);
        int WriteBuffer(int lStartIO, int lAddress, int lWriteSize, out short lpwData);
        int ReadBuffer(int lStartIO, int lAddress, int lWriteSize, out short lpwData);
        int Close();
    }

    /// <summary>   Mitsubi plc.  </summary>
    public class MitsubiPlc // : IPlcController 2012-04-24, Interface 삭제.
    {
        private IMitsubiPlc m_mitsubiPlc;
        private bool m_bOpen = false;
        private int m_Mode;
        #region  Ctor & Destructor.
        public MitsubiPlc(int mode)
        {
            if (mode == 0)
            {
                try
                {
                    m_mitsubiPlc = ActQJ71E71TCPDev.Instance();
                }
                catch (Exception ex)
                {
                    string[] str = ex.Message.Split('{', '}');
                    setReg64bit(str[1]);
                    Thread.Sleep(300);
                    m_mitsubiPlc = ActQJ71E71TCPDev.Instance();
                }
            }
            else
            {
                m_mitsubiPlc = ActQNUDECPUTCPDev.Instance();
            }
            m_Mode = mode;
        }

        ~MitsubiPlc()
        {
            // m_mitsubiPlc.Close();
        }
        #endregion

        public void setReg64bit(string regVal)
        {
            RegistryKey reg = Registry.ClassesRoot;
            RegistryKey reg1 = Registry.ClassesRoot;
            RegistryKey reg2 = Registry.LocalMachine;


            reg = reg.CreateSubKey("WOW6432Node\\CLSID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);
            reg.SetValue("AppID", "{" + regVal + "}", RegistryValueKind.String);
            reg.Flush();

            reg1 = reg1.CreateSubKey("WOW6432Node\\AppID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);
            reg1.SetValue("DllSurrogate", "", RegistryValueKind.String);
            reg1.Flush();

            reg2 = reg2.OpenSubKey("Software\\Classes\\AppID\\{" + regVal + "}", true);
            if (reg2 == null)
            {
                reg2 = Registry.LocalMachine.CreateSubKey("Software\\Classes\\AppID\\{" + regVal + "}", RegistryKeyPermissionCheck.ReadWriteSubTree);

            }
            reg.Close();
            reg2.Close();
        }

        public bool ConnectPLC(string ip, int port)
        {
            m_bOpen = m_mitsubiPlc.ConnectPLC(ip, port);
            return m_bOpen;
        }

        public int ReadData(string astrAddress)
        {
            int lData = 0;
            return m_mitsubiPlc.GetDeviceBlock(astrAddress, 1, out lData);
            //return lData;
        }

        public int WriteData(string astrAddress, int val)
        {
            m_mitsubiPlc.Write(astrAddress, 1, ref val);
            return 0;
        }

        private bool ReadBit(string astrAddress)
        {
            int lData = 0;
            return m_mitsubiPlc.GetDevice(astrAddress, out lData) == 1 ? true:false;
            //return lData;
        }

        public bool AutoMode(string astrAddress)
        {
            return ReadBit(astrAddress);
            //return lData;
        }

        public bool RequestJob(string astrAddress)
        {
            return ReadBit(astrAddress);
        }

        public bool RequestDone(string astrAddress)
        {
            return ReadBit(astrAddress);
        }

        public string ReadOrder(string astrAddress)
        {
            string s = "";
            //오더를 어떻게 읽어 올 지는 PLC와 협의 할 것
            return s;
        }

        public void GetResult(out int anCount, out int anBad, out int anConnect, string astrCount, string astrBad, string astrConnect)
        {
            anCount = ReadData(astrCount);
            anBad = ReadData(astrBad);
            anConnect = ReadData(astrConnect);
        }

        // 오더 정보 전송
        public void SendOrderData(int PF, int row, int Count, bool[,] data, string PFAddress, string RowAddress, string CountAddress, string MapAddress, string JobAddress)
        {
            WriteData(PFAddress, PF);
            WriteData(RowAddress, row);
            WriteData(CountAddress, Count);
            if (Count ==0)
            {
            }
            else
            {
                SendMapData(data, row, MapAddress, JobAddress);
            }
        }


        //astrStartAddress = 4자리로 고정하자
        //32Bit 단위로 개산해서 맵을 쓰준다.
        //
        private void SendMapData(bool[,] pMapData, int row, string astrStartAddress,string astrSendDoneAddress)
        {
            int stratpos = Convert.ToInt32(astrStartAddress.Substring(1, astrStartAddress.Length-1));
            int cnt = pMapData.Length;
            int iter = (int)Math.Ceiling((double)cnt / 32.0);
            int val = 0;
            for (int k = 0; k < row; k++)
            {
                for (int i = 0; i < iter; i++)
                {
                    val = 0;
                    if (cnt < (1 + i) * 32 - 1)
                    {
                        for (int j = 0; j < (cnt % 32); j++)
                        {
                            if (j == 0) val += ((pMapData[k,i * 32 + j]) ? 1 : 0);
                            else val += ((pMapData[k,i * 32 + j]) ? (j * 2) : 0);
                        }
                    }
                    else
                    {
                        for (int j = 0; j < 32; j++)
                        {
                            if (j == 0) val += ((pMapData[k,i * 32 + j]) ? 1 : 0);
                            else val += ((pMapData[k,i * 32 + j]) ? (j * 2) : 0);
                        }
                    }
                    WriteData("D" + (stratpos + i + (k*iter)).ToString(), val);
                }
            }
            Thread.Sleep(300);
            m_mitsubiPlc.SetDevice(astrSendDoneAddress, 1);
            Thread.Sleep(500);
            m_mitsubiPlc.SetDevice(astrSendDoneAddress, 0);
            Thread.Sleep(50);
        }


    }
}
